from django.contrib import admin
from django.urls import path
from .import views
from.import views
urlpatterns = [
    path('',views.index,name='index' ),
     path('collections',views.collections,name='collections' ),
]